#version 330
#moj_import <ji-afk-cinematic:focus.glsl>
in vec2 texCoord;
out vec4 fragColor;

void main() {
    vec4 original = texture(SceneSampler, texCoord);
    if (Screen.w > 0.5) {
        float vignette = edgeVignette(texCoord);
        float intensity = min(0.38, 0.10 + Focus.z * 0.06);
        vec3 blurred = toDisplay(texture(BlurSampler, texCoord).rgb);
        fragColor = vec4(mix(original.rgb, blurred, vignette * intensity * Focus.w), original.a);
        return;
    }
    float depth = viewDepth(texCoord);
    float coc = abs(circleOfConfusion(depth));
    float blend = smoothstep(0.5, 2.0, coc) * Focus.w;
    if (blend <= 0.0) { fragColor = original; return; }
    // Bilateral upsampling: retain full-resolution detail at subject silhouettes.
    vec2 size = vec2(textureSize(BlurSampler, 0));
    vec2 pixel = texCoord * size - 0.5;
    ivec2 base = ivec2(floor(pixel));
    vec2 fraction = fract(pixel);
    vec3 sum = vec3(0.0);
    float total = 0.0;
    for (int y = 0; y < 2; y++) for (int x = 0; x < 2; x++) {
        ivec2 p = clamp(base + ivec2(x, y), ivec2(0), ivec2(size) - 1);
        vec4 sampleColor = texelFetch(BlurSampler, p, 0);
        float spatial = (x == 0 ? 1.0 - fraction.x : fraction.x) * (y == 0 ? 1.0 - fraction.y : fraction.y);
        float edge = exp(-abs((exp2(sampleColor.a * 14.0) - 1.0) - depth) / max(0.08, depth * 0.025));
        float w = spatial * edge;
        sum += sampleColor.rgb * w; total += w;
    }
    vec3 blurred = total > 0.0001 ? toDisplay(sum / total) : original.rgb;
    fragColor = vec4(mix(original.rgb, blurred, blend), original.a);
}
